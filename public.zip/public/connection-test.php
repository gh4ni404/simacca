<?php
/**
 * Database Connection Test Script
 * 
 * Usage: https://simacca.smkn8bone.sch.id/connection-test.php
 * 
 * ⚠️ SECURITY: DELETE THIS FILE AFTER TESTING!
 * Or add IP whitelist below
 */

// ✅ IP Whitelist (uncomment and add your IP for security)
// $allowedIPs = ['your.ip.address.here'];
// if (!in_array($_SERVER['REMOTE_ADDR'], $allowedIPs)) {
//     die('Access denied');
// }

header('Content-Type: application/json; charset=utf-8');

$result = [
    'timestamp' => date('Y-m-d H:i:s'),
    'tests' => [],
    'overall' => 'unknown'
];

// Test 1: Database Connection
try {
    $mysqli = @new mysqli(
        'localhost',
        'smknbone_simacca_user',
        'gi2Bw~,_bU+8',
        'smknbone_simacca_database'
    );
    
    if ($mysqli->connect_error) {
        throw new Exception('Connection failed: ' . $mysqli->connect_error);
    }
    
    $result['tests']['database_connect'] = [
        'status' => 'PASS',
        'message' => 'Database connected successfully',
        'host_info' => $mysqli->host_info
    ];
    
    // Test 2: Simple Query
    try {
        $query = $mysqli->query('SELECT 1 as test, NOW() as server_time');
        if (!$query) {
            throw new Exception('Query failed: ' . $mysqli->error);
        }
        
        $row = $query->fetch_assoc();
        $result['tests']['database_query'] = [
            'status' => 'PASS',
            'message' => 'Query executed successfully',
            'server_time' => $row['server_time']
        ];
    } catch (Exception $e) {
        $result['tests']['database_query'] = [
            'status' => 'FAIL',
            'message' => $e->getMessage()
        ];
    }
    
    // Test 3: Check Tables
    try {
        $tables = $mysqli->query("SHOW TABLES");
        $tableCount = $tables ? $tables->num_rows : 0;
        
        $result['tests']['database_tables'] = [
            'status' => $tableCount > 0 ? 'PASS' : 'WARNING',
            'message' => "Found {$tableCount} tables",
            'count' => $tableCount
        ];
    } catch (Exception $e) {
        $result['tests']['database_tables'] = [
            'status' => 'FAIL',
            'message' => $e->getMessage()
        ];
    }
    
    // Test 4: Connection Timeout Test (10 seconds)
    try {
        set_time_limit(15);
        $start = microtime(true);
        
        for ($i = 0; $i < 10; $i++) {
            $test = $mysqli->query('SELECT SLEEP(0.5)');
            if (!$test) {
                throw new Exception('Connection lost during timeout test');
            }
        }
        
        $duration = microtime(true) - $start;
        $result['tests']['connection_stability'] = [
            'status' => 'PASS',
            'message' => 'Connection stable for 10 queries',
            'duration_seconds' => round($duration, 2)
        ];
    } catch (Exception $e) {
        $result['tests']['connection_stability'] = [
            'status' => 'FAIL',
            'message' => $e->getMessage()
        ];
    }
    
    $mysqli->close();
    
} catch (Exception $e) {
    $result['tests']['database_error'] = [
        'status' => 'FAIL',
        'message' => $e->getMessage()
    ];
}

// Test 5: File Permissions
$writablePath = __DIR__ . '/../writable';
$sessionPath = $writablePath . '/session';
$uploadPath = $writablePath . '/uploads';
$logsPath = $writablePath . '/logs';

$result['tests']['permissions'] = [
    'writable' => [
        'status' => is_writable($writablePath) ? 'PASS' : 'FAIL',
        'path' => $writablePath
    ],
    'session' => [
        'status' => is_writable($sessionPath) ? 'PASS' : 'FAIL',
        'path' => $sessionPath
    ],
    'uploads' => [
        'status' => is_writable($uploadPath) ? 'PASS' : 'FAIL',
        'path' => $uploadPath
    ],
    'logs' => [
        'status' => is_writable($logsPath) ? 'PASS' : 'FAIL',
        'path' => $logsPath
    ]
];

// Test 6: PHP Configuration
$result['tests']['php_config'] = [
    'version' => PHP_VERSION,
    'version_ok' => version_compare(PHP_VERSION, '8.1.0', '>=') ? 'PASS' : 'FAIL',
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time'),
    'upload_max_filesize' => ini_get('upload_max_filesize'),
    'post_max_size' => ini_get('post_max_size'),
    'mysqli_enabled' => extension_loaded('mysqli') ? 'PASS' : 'FAIL'
];

// Test 7: Keep-Alive Headers
$result['tests']['headers'] = [
    'connection_header' => isset($_SERVER['HTTP_CONNECTION']) ? $_SERVER['HTTP_CONNECTION'] : 'not set',
    'keep_alive' => isset($_SERVER['HTTP_KEEP_ALIVE']) ? $_SERVER['HTTP_KEEP_ALIVE'] : 'not set'
];

// Overall Status
$failCount = 0;
foreach ($result['tests'] as $test) {
    if (isset($test['status']) && $test['status'] === 'FAIL') {
        $failCount++;
    }
}

$result['overall'] = $failCount === 0 ? 'HEALTHY' : 'ISSUES_DETECTED';
$result['fail_count'] = $failCount;

// Pretty print JSON
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

// ⚠️ SECURITY REMINDER
echo "\n\n/* ⚠️ DELETE THIS FILE AFTER TESTING! */\n";
?>
