<?php
require 'vendor/autoload.php';

// Bootstrap CodeIgniter
$app = require_once FCPATH . '../app/Config/Paths.php';
$paths = new Config\Paths();
require FCPATH . '../vendor/codeigniter4/framework/system/bootstrap.php';

// Test base_url
echo "Base URL: " . base_url() . PHP_EOL;
echo "Sample foto URL: " . base_url('files/jurnal/jurnal_1768128258_69637f02e4e46.png') . PHP_EOL;
